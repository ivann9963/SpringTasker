package com.example.springtasker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringtaskerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringtaskerApplication.class, args);
	}

}
